﻿using System.ComponentModel.DataAnnotations;

namespace MovieCrud.Models
{
    public class Movie 
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        // New fields
        [Required]
        public string Age { get; set; }

        [Required]
        public string Gender { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [Phone]
        public string Phone { get; set; }

        [Required]
        public string Country { get; set; }

        [Required]
        public string State { get; set; }
    }
}
