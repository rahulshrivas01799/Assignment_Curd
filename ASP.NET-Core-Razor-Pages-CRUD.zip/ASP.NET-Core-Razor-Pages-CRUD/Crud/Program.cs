var builder = WebApplication.CreateBuilder(args);           
builder.Services.AddRazorPages();
 
            builder.services.AddDbContext<MovieContext>(options =>
                builder.options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
           
            builder.services.AddDbContext<MovieContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
            builder.services.AddTransient(typeof(IRepository<>), typeof(Repository<>));

            builder.services.AddRazorPages();
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseStaticFiles();
 
app.UseRouting();
 
app.UseAuthorization();
 
app.MapRazorPages();
 
app.Run();
